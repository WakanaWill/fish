import Phaser from 'phaser'

const eventsCenter = new Phaser.Events.EventEmitter()

export default eventsCenter