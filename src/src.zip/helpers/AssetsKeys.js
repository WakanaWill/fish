export default {
    fish:'fish',
    stal0:'sG0',
    stal1:'sG1',
    stal2:'sG2',
    stal3:'sG3',
    stal4:'sG5',
    stal5:'sG5',
    stal6:'sD0',
    stal7:'sD1',
    stal8:'sD2',
    stal9:'sD3',
    stal10:'sD4',
    stal11:'sD5', 
    finish:'meta'  
};
